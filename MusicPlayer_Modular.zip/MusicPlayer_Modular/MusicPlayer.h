#pragma once

#include "Playlist.h"

#include <SFML/Audio.hpp>

#include <random>
#include <string>

class MusicPlayer
{
private:
    sf::Music music;
    Playlist playlist;

    int currentIndex;
    float volume;

    bool isPlaying;
    bool shuffleMode;
    bool repeatMode;

    std::mt19937 randomEngine;

    void loadSongInternal(int index);
    int chooseNextIndex();

public:
    MusicPlayer();

    void loadInitialSongs();

    bool hasSongs() const;
    int songCount() const;
    const Playlist& getPlaylist() const;

    int currentSongIndex() const;
    const Song* currentSong() const;

    float getVolume() const;
    bool playing() const;
    bool shuffleEnabled() const;
    bool repeatEnabled() const;

    float currentTime() const;
    float totalTime() const;

    void playSong(int index);
    void togglePlayPause();
    void stop();

    void next();
    void previous();

    void changeVolume(float delta);
    void setVolumeFromMouse(float mouseX);
    void seekFromMouse(float mouseX);

    void toggleShuffle();
    void toggleRepeat();

    void addSong(const std::string& path);
    void removeCurrentSong();

    void savePlaylist() const;
    void loadSavedPlaylist();

    void update();
};

#pragma once

#include <SFML/Graphics.hpp>
#include <vector>

class MusicPlayer;

class PlayerUI
{
private:
    sf::Font& font;

    sf::Color background;
    sf::Color panel;
    sf::Color button;
    sf::Color hover;
    sf::Color active;
    sf::Color text;
    sf::Color muted;

    sf::RectangleShape previousButton;
    sf::RectangleShape playButton;
    sf::RectangleShape nextButton;
    sf::RectangleShape stopButton;

    sf::RectangleShape volumeBar;
    sf::CircleShape volumeKnob;

    sf::RectangleShape progressBar;
    sf::RectangleShape progressFill;
    sf::CircleShape progressKnob;

    sf::RectangleShape shuffleButton;
    sf::RectangleShape repeatButton;

    sf::RectangleShape addButton;
    sf::RectangleShape removeButton;
    sf::RectangleShape saveButton;
    sf::RectangleShape loadButton;

    sf::Text title;
    sf::Text subtitle;
    sf::Text songName;
    sf::Text playlistTitle;
    sf::Text modeText;
    sf::Text volumeText;
    sf::Text timeText;

    sf::Text previousText;
    sf::Text playText;
    sf::Text nextText;
    sf::Text stopText;

    sf::Text shuffleText;
    sf::Text repeatText;

    sf::Text addText;
    sf::Text removeText;
    sf::Text saveText;
    sf::Text loadText;

    std::vector<sf::RectangleShape> bars;
    sf::Clock visualizerClock;

    int playlistScroll;

    void setHover(sf::RectangleShape& shape, bool activeState = false);
    void updateText(const MusicPlayer& player);
    void updateProgress(const MusicPlayer& player);
    void updateVolume(const MusicPlayer& player);
    void updateVisualizer(const MusicPlayer& player);

public:
    explicit PlayerUI(sf::Font& loadedFont);

    void update(const MusicPlayer& player);

    void handlePlaylistScroll(sf::Vector2i mousePosition,
                              float delta,
                              int songCount);

    int songIndexAt(sf::Vector2f position, int songCount) const;

    void draw(sf::RenderWindow& window, const MusicPlayer& player);

    const sf::Color& backgroundColor() const;

    sf::FloatRect playButtonBounds() const;
    sf::FloatRect stopButtonBounds() const;
    sf::FloatRect nextButtonBounds() const;
    sf::FloatRect previousButtonBounds() const;

    sf::FloatRect shuffleButtonBounds() const;
    sf::FloatRect repeatButtonBounds() const;

    sf::FloatRect addButtonBounds() const;
    sf::FloatRect removeButtonBounds() const;
    sf::FloatRect saveButtonBounds() const;
    sf::FloatRect loadButtonBounds() const;

    sf::FloatRect volumeBounds() const;
    sf::FloatRect progressBounds() const;
};

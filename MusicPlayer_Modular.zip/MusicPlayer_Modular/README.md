# 🎵 Music Player — Modular C++ / SFML

A desktop music player built in **C++ with SFML 3**.

## Features

- Play / Pause / Stop
- Next / Previous
- MP3 and OGG support
- Volume control
- Seek/progress bar
- Automatic next song
- Shuffle
- Repeat
- Add/remove songs
- Scrollable playlist
- Save/load playlist
- Keyboard shortcuts
- Animated visualizer
- Separate classes and source files

## Architecture

```text
main.cpp
   |
   +---- MusicPlayer
   |       |
   |       +---- Playlist
   |       |       |
   |       |       +---- Song
   |       |
   |       +---- SFML Music
   |
   +---- PlayerUI
   |
   +---- FileManager
```

### Files

- `main.cpp` — application entry point and event routing
- `Song.h/.cpp` — represents one song
- `Playlist.h/.cpp` — stores and persists songs
- `MusicPlayer.h/.cpp` — playback/business logic
- `PlayerUI.h/.cpp` — GUI drawing and UI layout
- `FileManager.h/.cpp` — Windows file picker and copying audio files

## Build

```powershell
g++ -std=c++17 main.cpp Song.cpp Playlist.cpp MusicPlayer.cpp PlayerUI.cpp FileManager.cpp -o musicplayer -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -lcomdlg32
```

## Run

```powershell
.\musicplayer.exe
```

## Keyboard Shortcuts

| Key | Action |
|---|---|
| Space | Play/Pause |
| N | Next |
| P | Previous |
| S | Stop |
| Up | Volume + |
| Down | Volume - |
| H | Shuffle |
| R | Repeat |
| L | Save Playlist |
| O | Load Playlist |

## Author

**Keshav Kundra**  
Email: kundrakeshav85@gmail.com  
GitHub: https://github.com/kundrakeshav85-blip

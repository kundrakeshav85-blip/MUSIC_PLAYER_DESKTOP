#include "Playlist.h"

#include <fstream>

void Playlist::add(const Song& song)
{
    if (!containsPath(song.getPath()))
        songs.push_back(song);
}

void Playlist::remove(int index)
{
    if (index < 0 || index >= size())
        return;

    songs.erase(songs.begin() + index);
}

void Playlist::clear()
{
    songs.clear();
}

bool Playlist::empty() const
{
    return songs.empty();
}

int Playlist::size() const
{
    return static_cast<int>(songs.size());
}

Song* Playlist::get(int index)
{
    if (index < 0 || index >= size())
        return nullptr;

    return &songs[index];
}

const Song* Playlist::get(int index) const
{
    if (index < 0 || index >= size())
        return nullptr;

    return &songs[index];
}

const std::vector<Song>& Playlist::getSongs() const
{
    return songs;
}

bool Playlist::containsPath(const std::string& path) const
{
    for (const auto& song : songs)
    {
        if (song.getPath() == path)
            return true;
    }

    return false;
}

bool Playlist::save(const std::string& filePath) const
{
    std::ofstream file(filePath);

    if (!file)
        return false;

    for (const auto& song : songs)
        file << song.getPath() << '\n';

    return true;
}

bool Playlist::load(const std::string& filePath)
{
    std::ifstream file(filePath);

    if (!file)
        return false;

    std::vector<Song> loadedSongs;
    std::string path;

    while (std::getline(file, path))
    {
        if (path.empty())
            continue;

        loadedSongs.emplace_back(path);
    }

    songs = loadedSongs;
    return true;
}

#pragma once

#include "Song.h"

#include <string>
#include <vector>

class Playlist
{
private:
    std::vector<Song> songs;

public:
    void add(const Song& song);
    void remove(int index);
    void clear();

    bool empty() const;
    int size() const;

    Song* get(int index);
    const Song* get(int index) const;

    const std::vector<Song>& getSongs() const;

    bool containsPath(const std::string& path) const;

    bool save(const std::string& filePath) const;
    bool load(const std::string& filePath);
};

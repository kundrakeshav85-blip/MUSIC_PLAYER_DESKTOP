#pragma once

#include <SFML/Audio.hpp>
#include <string>

class Song
{
private:
    std::string path;

public:
    Song() = default;
    explicit Song(const std::string& filePath);

    const std::string& getPath() const;
    std::string getName() const;
    sf::Time getDuration() const;
};

#include "PlayerUI.h"
#include "MusicPlayer.h"

#include <algorithm>
#include <cstdio>
#include <cmath>
#include <filesystem>
#include <string>

PlayerUI::PlayerUI(sf::Font& loadedFont)
    : font(loadedFont),
      background(18, 18, 24),
      panel(28, 28, 36),
      button(55, 55, 68),
      hover(85, 85, 105),
      active(95, 95, 120),
      text(235, 235, 240),
      muted(160, 160, 170),
      playlistScroll(0)
{
    title = sf::Text(font, "MUSIC PLAYER", 38);
    title.setFillColor(text);
    title.setPosition({55, 35});

    subtitle = sf::Text(font, "Your personal music station", 17);
    subtitle.setFillColor(muted);
    subtitle.setPosition({58, 82});

    songName = sf::Text(font, "No Song", 27);
    songName.setFillColor(text);
    songName.setPosition({250, 145});

    playlistTitle = sf::Text(font, "PLAYLIST", 25);
    playlistTitle.setFillColor(text);
    playlistTitle.setPosition({715, 145});

    modeText = sf::Text(font, "SHUFFLE: OFF   REPEAT: OFF", 13);
    modeText.setFillColor(muted);
    modeText.setPosition({715, 170});

    previousButton = sf::RectangleShape({105, 52});
    previousButton.setPosition({115, 230});

    playButton = sf::RectangleShape({120, 52});
    playButton.setPosition({250, 230});

    nextButton = sf::RectangleShape({105, 52});
    nextButton.setPosition({400, 230});

    stopButton = sf::RectangleShape({105, 48});
    stopButton.setPosition({250, 300});

    previousText = sf::Text(font, "PREV", 18);
    previousText.setPosition({142, 245});

    playText = sf::Text(font, "PAUSE", 18);
    playText.setPosition({283, 245});

    nextText = sf::Text(font, "NEXT", 18);
    nextText.setPosition({427, 245});

    stopText = sf::Text(font, "STOP", 18);
    stopText.setPosition({281, 314});

    volumeText = sf::Text(font, "VOLUME: 70%", 18);
    volumeText.setPosition({255, 370});

    volumeBar = sf::RectangleShape({300, 7});
    volumeBar.setPosition({160, 410});
    volumeBar.setFillColor(sf::Color(70, 70, 82));

    volumeKnob = sf::CircleShape(9);
    volumeKnob.setFillColor(sf::Color(220, 220, 225));

    timeText = sf::Text(font, "00:00 / 00:00", 17);
    timeText.setFillColor(sf::Color(180, 180, 190));
    timeText.setPosition({275, 435});

    progressBar = sf::RectangleShape({500, 7});
    progressBar.setPosition({95, 475});
    progressBar.setFillColor(sf::Color(70, 70, 82));

    progressFill = sf::RectangleShape({0, 7});
    progressFill.setPosition({95, 475});
    progressFill.setFillColor(sf::Color(170, 170, 180));

    progressKnob = sf::CircleShape(8);
    progressKnob.setFillColor(sf::Color(230, 230, 235));

    shuffleButton = sf::RectangleShape({110, 42});
    shuffleButton.setPosition({115, 500});

    shuffleText = sf::Text(font, "SHUFFLE", 15);
    shuffleText.setPosition({135, 513});

    repeatButton = sf::RectangleShape({110, 42});
    repeatButton.setPosition({400, 500});

    repeatText = sf::Text(font, "REPEAT", 15);
    repeatText.setPosition({425, 513});

    addButton = sf::RectangleShape({105, 38});
    addButton.setPosition({710, 515});

    addText = sf::Text(font, "+ ADD", 15);
    addText.setPosition({733, 526});

    removeButton = sf::RectangleShape({105, 38});
    removeButton.setPosition({835, 515});

    removeText = sf::Text(font, "- REMOVE", 15);
    removeText.setPosition({843, 526});

    saveButton = sf::RectangleShape({105, 38});
    saveButton.setPosition({710, 560});

    saveText = sf::Text(font, "SAVE", 15);
    saveText.setPosition({744, 571});

    loadButton = sf::RectangleShape({105, 38});
    loadButton.setPosition({835, 560});

    loadText = sf::Text(font, "LOAD", 15);
    loadText.setPosition({860, 571});

    for (int i = 0; i < 22; ++i)
    {
        sf::RectangleShape bar({12, 20});
        bar.setFillColor(sf::Color(120, 120, 135));
        bars.push_back(bar);
    }

    // Text values are populated on the first update() call.
}

void PlayerUI::setHover(sf::RectangleShape& shape, bool activeState)
{
    shape.setFillColor(
        activeState ? active : button
    );
}

void PlayerUI::updateText(const MusicPlayer& player)
{
    if (player.currentSong())
        songName.setString(player.currentSong()->getName());
    else
        songName.setString("No Song");

    playText.setString(player.playing() ? "PAUSE" : "PLAY");

    modeText.setString(
        std::string("SHUFFLE: ") +
        (player.shuffleEnabled() ? "ON" : "OFF") +
        "   REPEAT: " +
        (player.repeatEnabled() ? "ON" : "OFF")
    );
}

void PlayerUI::updateProgress(const MusicPlayer& player)
{
    float current = player.currentTime();
    float total = player.totalTime();

    if (total > 0)
    {
        float progress = std::clamp(current / total, 0.0f, 1.0f);

        progressFill.setSize({500.0f * progress, 7});
        progressKnob.setPosition({
            95.0f + 500.0f * progress - 8.0f,
            466.0f
        });
    }
    else
    {
        progressFill.setSize({0, 7});
        progressKnob.setPosition({87, 466});
    }

    auto formatTime = [](float seconds)
    {
        int totalSeconds = static_cast<int>(seconds);
        int minutes = totalSeconds / 60;
        int secs = totalSeconds % 60;

        char buffer[16];
        std::snprintf(
            buffer,
            sizeof(buffer),
            "%02d:%02d",
            minutes,
            secs
        );

        return std::string(buffer);
    };

    timeText.setString(
        formatTime(current) +
        " / " +
        formatTime(total)
    );
}

void PlayerUI::updateVolume(const MusicPlayer& player)
{
    float volume = player.getVolume();

    volumeText.setString(
        "VOLUME: " +
        std::to_string(static_cast<int>(volume)) +
        "%"
    );

    float knobX = 160.0f + (volume / 100.0f) * 300.0f;

    volumeKnob.setPosition({
        knobX - 9,
        401
    });
}

void PlayerUI::updateVisualizer(const MusicPlayer& player)
{
    float elapsed =
        visualizerClock.getElapsedTime().asSeconds();

    for (int i = 0; i < static_cast<int>(bars.size()); ++i)
    {
        float height =
            10.0f +
            std::abs(
                std::sin(
                    elapsed * 4.0f +
                    i * 0.6f
                )
            ) * 35.0f;

        if (!player.playing())
            height = 10.0f;

        bars[i].setSize({12, height});
        bars[i].setPosition({
            85.0f + i * 22.0f,
            615.0f - height
        });
    }
}

void PlayerUI::update(const MusicPlayer& player)
{
    updateText(player);
    updateProgress(player);
    updateVolume(player);
    updateVisualizer(player);

    // Hover colors are updated inside draw(), where the window is available.
}

void PlayerUI::handlePlaylistScroll(
    sf::Vector2i mousePosition,
    float delta,
    int songCount)
{
    if (mousePosition.x < 680 ||
        mousePosition.x > 980 ||
        mousePosition.y < 205 ||
        mousePosition.y > 500)
    {
        return;
    }

    if (delta < 0)
        ++playlistScroll;
    else if (delta > 0)
        --playlistScroll;

    int maxScroll =
        std::max(0, songCount - 7);

    playlistScroll =
        std::clamp(playlistScroll, 0, maxScroll);
}

int PlayerUI::songIndexAt(
    sf::Vector2f position,
    int songCount) const
{
    int visible = std::min(7, songCount);

    for (int i = 0; i < visible; ++i)
    {
        int index = i + playlistScroll;
        float y = 205.0f + i * 48.0f;

        sf::FloatRect area(
            {710, y},
            {220, 42}
        );

        if (area.contains(position))
            return index;
    }

    return -1;
}

void PlayerUI::draw(
    sf::RenderWindow& window,
    const MusicPlayer& player)
{
    sf::RectangleShape mainPanel({610, 500});
    mainPanel.setPosition({40, 120});
    mainPanel.setFillColor(panel);

    sf::RectangleShape playlistPanel({280, 500});
    playlistPanel.setPosition({680, 120});
    playlistPanel.setFillColor(panel);

    sf::Vector2i mouse =
        sf::Mouse::getPosition(window);

    sf::Vector2f mouseFloat(
        static_cast<float>(mouse.x),
        static_cast<float>(mouse.y)
    );

    auto normalHover =
        [&](sf::RectangleShape& shape)
    {
        shape.setFillColor(
            shape.getGlobalBounds().contains(mouseFloat)
                ? hover
                : button
        );
    };

    normalHover(previousButton);
    normalHover(playButton);
    normalHover(nextButton);
    normalHover(stopButton);
    normalHover(addButton);
    normalHover(removeButton);
    normalHover(saveButton);
    normalHover(loadButton);

    shuffleButton.setFillColor(
        shuffleButton.getGlobalBounds().contains(mouseFloat)
            ? hover
            : (player.shuffleEnabled() ? active : button)
    );

    repeatButton.setFillColor(
        repeatButton.getGlobalBounds().contains(mouseFloat)
            ? hover
            : (player.repeatEnabled() ? active : button)
    );

    window.draw(title);
    window.draw(subtitle);
    window.draw(mainPanel);
    window.draw(playlistPanel);

    window.draw(songName);

    window.draw(previousButton);
    window.draw(playButton);
    window.draw(nextButton);
    window.draw(stopButton);

    window.draw(previousText);
    window.draw(playText);
    window.draw(nextText);
    window.draw(stopText);

    window.draw(volumeText);
    window.draw(volumeBar);
    window.draw(volumeKnob);

    window.draw(timeText);

    window.draw(progressBar);
    window.draw(progressFill);
    window.draw(progressKnob);

    window.draw(shuffleButton);
    window.draw(repeatButton);
    window.draw(shuffleText);
    window.draw(repeatText);

    window.draw(playlistTitle);
    window.draw(modeText);

    int visible = std::min(7, player.songCount());

    for (int i = 0; i < visible; ++i)
    {
        int index = i + playlistScroll;
        const Song* song = player.getPlaylist().get(index);

        if (!song)
            continue;

        float y = 205.0f + i * 48.0f;

        sf::RectangleShape songBox({220, 42});
        songBox.setPosition({710, y});

        if (index == player.currentSongIndex())
            songBox.setFillColor(active);
        else
            songBox.setFillColor(sf::Color(45, 45, 55));

        sf::Text songText(
            font,
            song->getName(),
            16
        );

        songText.setFillColor(text);
        songText.setPosition({725, y + 10});

        window.draw(songBox);
        window.draw(songText);
    }

    window.draw(addButton);
    window.draw(addText);

    window.draw(removeButton);
    window.draw(removeText);

    window.draw(saveButton);
    window.draw(saveText);

    window.draw(loadButton);
    window.draw(loadText);

    for (auto& bar : bars)
        window.draw(bar);
}

const sf::Color& PlayerUI::backgroundColor() const
{
    return background;
}

sf::FloatRect PlayerUI::playButtonBounds() const
{
    return playButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::stopButtonBounds() const
{
    return stopButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::nextButtonBounds() const
{
    return nextButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::previousButtonBounds() const
{
    return previousButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::shuffleButtonBounds() const
{
    return shuffleButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::repeatButtonBounds() const
{
    return repeatButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::addButtonBounds() const
{
    return addButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::removeButtonBounds() const
{
    return removeButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::saveButtonBounds() const
{
    return saveButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::loadButtonBounds() const
{
    return loadButton.getGlobalBounds();
}

sf::FloatRect PlayerUI::volumeBounds() const
{
    return volumeBar.getGlobalBounds();
}

sf::FloatRect PlayerUI::progressBounds() const
{
    return progressBar.getGlobalBounds();
}

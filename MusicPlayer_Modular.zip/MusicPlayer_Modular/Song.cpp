#include "Song.h"

#include <filesystem>

Song::Song(const std::string& filePath)
    : path(filePath)
{
}

const std::string& Song::getPath() const
{
    return path;
}

std::string Song::getName() const
{
    return std::filesystem::path(path).filename().string();
}

sf::Time Song::getDuration() const
{
    sf::Music music;

    if (!music.openFromFile(path))
        return sf::Time::Zero;

    return music.getDuration();
}

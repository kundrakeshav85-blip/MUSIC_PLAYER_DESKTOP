#include <SFML/Graphics.hpp>
#include <iostream>

#include "MusicPlayer.h"
#include "PlayerUI.h"
#include "FileManager.h"

int main()
{
    sf::RenderWindow window(
        sf::VideoMode({1000, 650}),
        "Music Player"
    );
    window.setFramerateLimit(60);

    sf::Font font;
    if (!font.openFromFile("C:/Windows/Fonts/arial.ttf"))
    {
        std::cout << "Font not found!\n";
        return 1;
    }

    MusicPlayer player;
    player.loadInitialSongs();

    if (!player.hasSongs())
    {
        std::cout << "No songs found in the songs folder.\n";
        return 1;
    }

    PlayerUI ui(font);

    while (window.isOpen())
    {
        while (auto event = window.pollEvent())
        {
            if (event->is<sf::Event::Closed>())
            {
                window.close();
            }

            if (auto key = event->getIf<sf::Event::KeyPressed>())
            {
                switch (key->code)
                {
                    case sf::Keyboard::Key::Space:
                        player.togglePlayPause();
                        break;

                    case sf::Keyboard::Key::N:
                        player.next();
                        break;

                    case sf::Keyboard::Key::P:
                        player.previous();
                        break;

                    case sf::Keyboard::Key::S:
                        player.stop();
                        break;

                    case sf::Keyboard::Key::Up:
                        player.changeVolume(10.0f);
                        break;

                    case sf::Keyboard::Key::Down:
                        player.changeVolume(-10.0f);
                        break;

                    case sf::Keyboard::Key::H:
                        player.toggleShuffle();
                        break;

                    case sf::Keyboard::Key::R:
                        player.toggleRepeat();
                        break;

                    case sf::Keyboard::Key::L:
                        player.savePlaylist();
                        break;

                    case sf::Keyboard::Key::O:
                        player.loadSavedPlaylist();
                        break;

                    default:
                        break;
                }
            }

            if (auto wheel = event->getIf<sf::Event::MouseWheelScrolled>())
            {
                ui.handlePlaylistScroll(wheel->position, wheel->delta,
                                         player.songCount());
            }

            if (auto mouse = event->getIf<sf::Event::MouseButtonPressed>())
            {
                if (mouse->button == sf::Mouse::Button::Left)
                {
                    sf::Vector2f position(
                        static_cast<float>(mouse->position.x),
                        static_cast<float>(mouse->position.y)
                    );

                    if (ui.playButtonBounds().contains(position))
                        player.togglePlayPause();

                    else if (ui.stopButtonBounds().contains(position))
                        player.stop();

                    else if (ui.nextButtonBounds().contains(position))
                        player.next();

                    else if (ui.previousButtonBounds().contains(position))
                        player.previous();

                    else if (ui.shuffleButtonBounds().contains(position))
                        player.toggleShuffle();

                    else if (ui.repeatButtonBounds().contains(position))
                        player.toggleRepeat();

                    else if (ui.saveButtonBounds().contains(position))
                        player.savePlaylist();

                    else if (ui.loadButtonBounds().contains(position))
                        player.loadSavedPlaylist();

                    else if (ui.addButtonBounds().contains(position))
                    {
                        std::string newSong = FileManager::addSongWithDialog();

                        if (!newSong.empty())
                            player.addSong(newSong);
                    }

                    else if (ui.removeButtonBounds().contains(position))
                        player.removeCurrentSong();

                    else if (ui.volumeBounds().contains(position))
                        player.setVolumeFromMouse(position.x);

                    else if (ui.progressBounds().contains(position))
                        player.seekFromMouse(position.x);

                    else
                    {
                        int clickedSong = ui.songIndexAt(position,
                                                         player.songCount());

                        if (clickedSong >= 0)
                            player.playSong(clickedSong);
                    }
                }
            }
        }

        // Automatically move to the next/repeated song after natural completion.
        player.update();

        ui.update(player);

        window.clear(ui.backgroundColor());

        ui.draw(window, player);

        window.display();
    }

    return 0;
}

#include "FileManager.h"

#include <windows.h>
#include <commdlg.h>

#include <filesystem>
#include <iostream>

std::string FileManager::addSongWithDialog()
{
    char fileName[MAX_PATH] = "";

    OPENFILENAMEA dialog{};
    dialog.lStructSize = sizeof(dialog);
    dialog.lpstrFile = fileName;
    dialog.nMaxFile = MAX_PATH;

    dialog.lpstrFilter =
        "Audio Files (MP3/OGG)\\0*.mp3;*.ogg\\0"
        "MP3 Audio Files\\0*.mp3\\0"
        "OGG Audio Files\\0*.ogg\\0"
        "All Files\\0*.*\\0";

    dialog.nFilterIndex = 1;
    dialog.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if (!GetOpenFileNameA(&dialog))
        return "";

    try
    {
        std::filesystem::create_directories("songs");

        std::filesystem::path selected(fileName);
        std::filesystem::path destination =
            std::filesystem::path("songs") / selected.filename();

        std::filesystem::copy_file(
            selected,
            destination,
            std::filesystem::copy_options::overwrite_existing
        );

        return destination.string();
    }
    catch (const std::exception& e)
    {
        std::cout << "Could not add song: "
                  << e.what() << '\n';

        return "";
    }
}

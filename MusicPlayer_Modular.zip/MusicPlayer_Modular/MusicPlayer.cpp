#include "MusicPlayer.h"

#include <filesystem>
#include <iostream>
#include <algorithm>
#include <cctype>

MusicPlayer::MusicPlayer()
    : currentIndex(0),
      volume(70.0f),
      isPlaying(false),
      shuffleMode(false),
      repeatMode(false),
      randomEngine(std::random_device{}())
{
    music.setVolume(volume);
}

void MusicPlayer::loadInitialSongs()
{
    std::filesystem::create_directories("songs");

    // Automatically discover MP3 and OGG files in the songs folder.
    std::vector<std::filesystem::path> discovered;

    for (const auto& entry : std::filesystem::directory_iterator("songs"))
    {
        if (!entry.is_regular_file())
            continue;

        std::string extension = entry.path().extension().string();

        std::transform(
            extension.begin(),
            extension.end(),
            extension.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); }
        );

        if (extension == ".mp3" || extension == ".ogg")
            discovered.push_back(entry.path());
    }

    std::sort(discovered.begin(), discovered.end());

    for (const auto& path : discovered)
        playlist.add(Song(path.string()));

    if (!playlist.empty())
        loadSongInternal(0);
}

bool MusicPlayer::hasSongs() const
{
    return !playlist.empty();
}

int MusicPlayer::songCount() const
{
    return playlist.size();
}

const Playlist& MusicPlayer::getPlaylist() const
{
    return playlist;
}

int MusicPlayer::currentSongIndex() const
{
    return currentIndex;
}

const Song* MusicPlayer::currentSong() const
{
    return playlist.get(currentIndex);
}

float MusicPlayer::getVolume() const
{
    return volume;
}

bool MusicPlayer::playing() const
{
    return isPlaying;
}

bool MusicPlayer::shuffleEnabled() const
{
    return shuffleMode;
}

bool MusicPlayer::repeatEnabled() const
{
    return repeatMode;
}

float MusicPlayer::currentTime() const
{
    return music.getPlayingOffset().asSeconds();
}

float MusicPlayer::totalTime() const
{
    return music.getDuration().asSeconds();
}

void MusicPlayer::loadSongInternal(int index)
{
    if (index < 0 || index >= playlist.size())
        return;

    const Song* song = playlist.get(index);

    if (!song)
        return;

    if (!music.openFromFile(song->getPath()))
    {
        std::cout << "Could not load: "
                  << song->getPath() << '\n';

        isPlaying = false;
        return;
    }

    currentIndex = index;
    music.setVolume(volume);
    music.play();
    isPlaying = true;
}

void MusicPlayer::playSong(int index)
{
    loadSongInternal(index);
}

void MusicPlayer::togglePlayPause()
{
    if (playlist.empty())
        return;

    if (isPlaying)
    {
        music.pause();
        isPlaying = false;
    }
    else
    {
        music.play();
        isPlaying = true;
    }
}

void MusicPlayer::stop()
{
    music.stop();
    isPlaying = false;
}

void MusicPlayer::next()
{
    if (playlist.empty())
        return;

    loadSongInternal(chooseNextIndex());
}

void MusicPlayer::previous()
{
    if (playlist.empty())
        return;

    int previousIndex = currentIndex - 1;

    if (previousIndex < 0)
        previousIndex = playlist.size() - 1;

    loadSongInternal(previousIndex);
}

int MusicPlayer::chooseNextIndex()
{
    if (playlist.size() <= 1)
        return 0;

    if (shuffleMode)
    {
        std::uniform_int_distribution<int> distribution(
            0,
            playlist.size() - 1
        );

        int nextIndex;

        do
        {
            nextIndex = distribution(randomEngine);
        }
        while (nextIndex == currentIndex);

        return nextIndex;
    }

    int nextIndex = currentIndex + 1;

    if (nextIndex >= playlist.size())
        nextIndex = 0;

    return nextIndex;
}

void MusicPlayer::changeVolume(float delta)
{
    volume += delta;

    volume = std::max(0.0f, std::min(100.0f, volume));

    music.setVolume(volume);
}

void MusicPlayer::setVolumeFromMouse(float mouseX)
{
    float x = std::max(160.0f, std::min(460.0f, mouseX));

    volume = ((x - 160.0f) / 300.0f) * 100.0f;
    music.setVolume(volume);
}

void MusicPlayer::seekFromMouse(float mouseX)
{
    float x = std::max(95.0f, std::min(595.0f, mouseX));

    float progress = (x - 95.0f) / 500.0f;
    float duration = totalTime();

    if (duration > 0)
    {
        music.setPlayingOffset(
            sf::seconds(progress * duration)
        );
    }
}

void MusicPlayer::toggleShuffle()
{
    shuffleMode = !shuffleMode;
}

void MusicPlayer::toggleRepeat()
{
    repeatMode = !repeatMode;
}

void MusicPlayer::addSong(const std::string& path)
{
    if (path.empty())
        return;

    playlist.add(Song(path));

    if (playlist.size() == 1)
        loadSongInternal(0);
}

void MusicPlayer::removeCurrentSong()
{
    if (playlist.empty())
        return;

    playlist.remove(currentIndex);

    if (playlist.empty())
    {
        music.stop();
        currentIndex = 0;
        isPlaying = false;
        return;
    }

    if (currentIndex >= playlist.size())
        currentIndex = playlist.size() - 1;

    loadSongInternal(currentIndex);
}

void MusicPlayer::savePlaylist() const
{
    if (playlist.save("playlist.txt"))
        std::cout << "Playlist saved to playlist.txt\n";
    else
        std::cout << "Could not save playlist.\n";
}

void MusicPlayer::loadSavedPlaylist()
{
    Playlist loaded;

    if (!loaded.load("playlist.txt"))
    {
        std::cout << "No saved playlist found.\n";
        return;
    }

    playlist = loaded;

    if (playlist.empty())
    {
        music.stop();
        currentIndex = 0;
        isPlaying = false;
        return;
    }

    currentIndex = std::min(
        currentIndex,
        playlist.size() - 1
    );

    loadSongInternal(currentIndex);
}

void MusicPlayer::update()
{
    if (!isPlaying || playlist.empty())
        return;

    if (music.getStatus() != sf::Music::Status::Stopped)
        return;

    if (repeatMode)
    {
        music.setPlayingOffset(sf::seconds(0));
        music.play();
        return;
    }

    next();
}

@echo off
g++ -std=c++17 main.cpp Song.cpp Playlist.cpp MusicPlayer.cpp PlayerUI.cpp FileManager.cpp -o musicplayer -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -lcomdlg32
if %errorlevel% neq 0 pause
